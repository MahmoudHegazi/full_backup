<?php 
$ticket_id = $ticket_title = $ticket_date = $ticket_creator =  "";

$query = "SELECT * FROM maintenance";

?>

<?php 
$getloged_id = $_SESSION['id'];


$query = "SELECT * FROM users WHERE id=" . $getloged_id;
$res = mysqli_query($con, $query);


while ($row = mysqli_fetch_assoc($res)) {
	 $uid = $row['id'];
	 $user = $row['name'];
	 $userimage = $row['image'];
}


// get * ticket created by loged in user 
$query = "SELECT * FROM `maintenance` WHERE creator_id =" . $uid;
$res = mysqli_query($con, $query);
$count_rows = mysqli_num_rows ($res);
while ($row = mysqli_fetch_assoc($res)) {
   
	 $ticket_title = $row['title'];
	 echo $row['id'];
	 $ticket_id = $row['id'];
	 $ticket_creator_id = $row['creator_id'];
	 $ticket_supplier_id = $row['supplier_id'];
	 $ticket_last_employee_id = $row['last_employee_id'];
	 $ticket_device_id = $row['device_id'];
	 $ticket_price = $row['price'];
	 $ticket_date = $row['date'];
	 
	 echo "<tr>";
	 echo "<td>" . $ticket_id . "</td>";
	 echo "<td>" . $ticket_title . "</td>";
	 echo "<td>" . $ticket_date . "</td>";
	 echo "<td>" . $ticket_creator_id . "</td>";
	 echo "<td>" . $ticket_device_id . "</td>";
     
	 echo "		<td>
		 <select class='form-control' name='sticket_status'>
		    <option name='open' value='open'>Open</option>
			<option name='pending' value='pending'>Pending</option>
			<option name='closed' value='closed'>Closed</option>
			<option name='reopen' value='reopen'>Re-open</option>
		 </select>
		</td></tr> ";
}

?>

<br /><br />  
<div class="container table-responsive-sm col-mid-8" style="width:80%;">
  <table class="table table-bordered table-hover">
    <thead>
      <tr style="background-color:;color:white;">
	        <th>ID</th>
                <th>Title</th>
                <th>Date</th>
                <th>Creator</th>
                <th>Actions</th>
		
      </tr>
    </thead>
    <tbody>
      <tr>
	 <td>1</td>
        <td><?php echo $ticket_title; ?></td>
        <td>4/15/2020</td>
        <td>Mahmoud</td>

		<td>
		 <select class="form-control" name="sticket_status">
		    <option name="open" value="open">Open</option>
			<option name="pending" value="pending">Pending</option>
			<option name="closed" value="closed">Closed</option>
			<option name="reopen" value="reopen">Re-open</option>
		 </select>
		</td>
      </tr>
    </tbody>
  </table>
</div>